from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Dummy user data (In a real app, you would use a database)
users = {
    'user1': {'name': 'John Doe', 'balance': 1000},
    'user2': {'name': 'Jane Doe', 'balance': 1500}
}

@app.route('/')
def home():
    return render_template('index.html', users=users)

@app.route('/transfer', methods=['POST'])
def transfer():
    from_user = request.form['from_user']
    to_user = request.form['to_user']
    amount = float(request.form['amount'])

    if from_user not in users or to_user not in users:
        return 'Invalid user'

    if users[from_user]['balance'] < amount:
        return 'Insufficient funds'

    users[from_user]['balance'] -= amount
    users[to_user]['balance'] += amount

    return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)
